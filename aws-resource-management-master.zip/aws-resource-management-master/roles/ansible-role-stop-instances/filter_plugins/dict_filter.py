#!/usr/bin/python
class FilterModule(object):
    def filters(self):
        return {
            'lstest_dict': self.lstest_dict,
            'sort_dict': self.sort_dict,
            'sort_nested_dict': self.sort_nested_dict,
            'filter_dict': self.filter_dict,
            'filter_ec2_list': self.filter_ec2_list
        }

    def lstest_dict(self, dict_to_sort, sorting_key):
        return sorted(dict_to_sort, key=lambda k: k[sorting_key], reverse=True)[0]
    
    def sort_dict(self, dict_to_sort, sorting_key):
        return sorted(dict_to_sort, key=lambda k: k[sorting_key], reverse=True)
    
    def sort_nested_dict(self, dict_to_sort, sorting_key, order):
        return sorted(dict_to_sort, key=lambda k: k['tags'][sorting_key], reverse=order)
    
    def filter_dict(self, dict_to_filter, sorting_key):
        return dict_to_filter[sorting_key]

    def filter_ec2_list(self, filter_list, filter_tag, filter_name):
        output = []
        for instance in filter_list:
            if filter_name in instance['tags']['Name']:
                for tag in instance['tags']:
                    if filter_tag in tag:
                        output.append(instance)
        
        return output